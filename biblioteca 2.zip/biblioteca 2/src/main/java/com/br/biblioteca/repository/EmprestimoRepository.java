package com.br.biblioteca.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.br.biblioteca.entity.Emprestimo;

@Repository
public interface EmprestimoRepository extends JpaRepository<Emprestimo, Long> {

    List<Emprestimo> findByIdUserAndEntregaRealizada(Long idUsuario, boolean isEntregaRealizada);

    Emprestimo findByIdUserAndIdLivroAndEntregaRealizada(Long idUsuario, Long idLivro, boolean isEntregaRealizada);

    List<Emprestimo> findByUserId(Long id);
}
