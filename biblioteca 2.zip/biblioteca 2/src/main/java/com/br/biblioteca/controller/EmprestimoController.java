package com.br.biblioteca.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.br.biblioteca.service.EmprestimoService;

import java.time.LocalDate;

@RestController
@RequestMapping("/emprestimos")
public class EmprestimoController {

    private final EmprestimoService emprestimoService;

    public EmprestimoController(EmprestimoService emprestimoService) {
        this.emprestimoService = emprestimoService;
    }

    @PostMapping("/emprestar")
    public String emprestarLivro(@RequestParam Long idUser, @RequestParam Long idLivro,
            @RequestParam String dataDeEntrega) throws Exception {
        LocalDate dataEntrega = LocalDate.parse(dataDeEntrega);
        return emprestimoService.emprestarLivro(idUser, idLivro, dataEntrega);
    }

    @PostMapping("/entregar")
    public ResponseEntity<String> entregarLivro(@RequestParam Long idEmprestimos) {
        String mensagem = emprestimoService.entregarLivro(idEmprestimos);
        if (mensagem.contains("Atenção")) {
            return ResponseEntity.badRequest().body(mensagem);
        } else {
            return ResponseEntity.ok().body(mensagem);
        }
    }
}
