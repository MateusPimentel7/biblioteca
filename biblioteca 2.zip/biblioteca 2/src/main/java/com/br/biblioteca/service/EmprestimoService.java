package com.br.biblioteca.service;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.br.biblioteca.entity.Emprestimo;
import com.br.biblioteca.repository.EmprestimoRepository;

@Service
public class EmprestimoService {

    private final EmprestimoRepository emprestimosRepository;
    private final UsuarioService userService;

    @Autowired
    public EmprestimoService(EmprestimoRepository emprestimosRepository, UsuarioService userService) {
        this.emprestimosRepository = emprestimosRepository;
        this.userService = userService;
    }

    public String emprestarLivro(Long idUser, Long idLivro, LocalDate dataDeEntrega) {
        try {
            if (!userService.verificarPossibilidadeDeEmprestimo(idUser)) {
                return "Atenção: O usuário atingiu o limite máximo de empréstimos não devolvidos.";
            }

            if (!userService.verificarLivroJaEmprestado(idUser, idLivro)) {
                return "Atenção: O usuário já possui este livro emprestado e não devolvido.";
            }

            Emprestimo emprestimo = new Emprestimo(null, idLivro, idUser, LocalDate.now(), dataDeEntrega, false);
            emprestimosRepository.save(emprestimo);
            return "Empréstimo realizado com sucesso!";
        } catch (Exception e) {
            return "Erro ao realizar empréstimo de livro: " + e.getMessage();
        }
    }

    public String entregarLivro(Long idEmprestimo) {
        try {
            Optional<Emprestimo> emprestimoOptional = emprestimosRepository.findById(idEmprestimo);
            if (!emprestimoOptional.isPresent()) {
                return "Atenção: Empréstimo não encontrado.";
            }

            Emprestimo emprestimo = emprestimoOptional.get();
            if (emprestimo.isEntregaRealizada()) {
                return "Atenção: O livro já foi entregue anteriormente.";
            }

            emprestimo.setEntregaRealizada(true);
            emprestimosRepository.save(emprestimo);
            return "Livro entregue com sucesso!";
        } catch (Exception e) {
            return "Erro ao entregar livro: " + e.getMessage();
        }
    }
}
