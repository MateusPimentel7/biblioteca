package com.br.biblioteca.service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.stereotype.Service;
import com.br.biblioteca.entity.Emprestimo;
import com.br.biblioteca.entity.Usuario;
import com.br.biblioteca.repository.EmprestimoRepository;
import com.br.biblioteca.repository.UsuarioRepository;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final EmprestimoRepository emprestimosRepository;

    public UsuarioService(UsuarioRepository usuarioRepository, EmprestimoRepository emprestimosRepository) {
        this.usuarioRepository = usuarioRepository;
        this.emprestimosRepository = emprestimosRepository;
    }

    public Usuario cadastrarUsuario(Usuario user) {
        return usuarioRepository.save(user);
    }

    public boolean verificarPossibilidadeDeEmprestimo(Long idUsuario) {
        List<Emprestimo> emprestimosNaoEntregues = emprestimosRepository
                .findByIdUserAndEntregaRealizada(idUsuario, false);
        return emprestimosNaoEntregues.size() <= 3;
    }

    public boolean verificarLivroJaEmprestado(Long idUsuario, Long idLivro) {
        Emprestimo emprestimoExistente = emprestimosRepository.findByIdUserAndIdLivroAndEntregaRealizada(idUsuario,
                idLivro, false);
        return emprestimoExistente == null;
    }

    public Optional<Usuario> getUsuarioById(Long usuarioId) {
        return (Optional<Usuario>) usuarioRepository.getUsuarioById(usuarioId);
    }

    public Optional<Usuario> findById(Long id) {
        return usuarioRepository.findById(id);
    }

    public void deletarUsuario(Long id) {
        java.util.Optional<Usuario> usuarioOptional = usuarioRepository.findById(id);
        if (usuarioOptional.isPresent()) {
            Usuario usuario = usuarioOptional.get();
            List<Emprestimo> emprestimosDoUsuario = emprestimosRepository.findByUserId(id);
            emprestimosRepository.deleteAll(emprestimosDoUsuario);
            usuarioRepository.delete(usuario);
        } else {
            throw new NoSuchElementException("Usuário não encontrado com o ID: " + id);
        }
    }

}
